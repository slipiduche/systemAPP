package com.example.systemAPP

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
